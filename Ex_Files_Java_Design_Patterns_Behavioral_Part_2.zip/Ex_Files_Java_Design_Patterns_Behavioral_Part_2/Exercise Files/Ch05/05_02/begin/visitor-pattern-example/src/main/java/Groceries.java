public interface Groceries {

  double getPrice();

}
