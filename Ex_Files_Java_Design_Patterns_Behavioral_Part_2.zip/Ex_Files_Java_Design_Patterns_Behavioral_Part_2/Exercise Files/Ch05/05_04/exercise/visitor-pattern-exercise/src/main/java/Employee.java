public interface Employee {

  int getSalary();

}
