public interface Account {

  void makePayment(int amount);

}
