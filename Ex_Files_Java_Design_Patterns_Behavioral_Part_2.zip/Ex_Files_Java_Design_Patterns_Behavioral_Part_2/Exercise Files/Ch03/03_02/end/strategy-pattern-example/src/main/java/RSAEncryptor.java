public class RSAEncryptor implements Encryptor {

  public String encryptFile() {
    return "Applying RSA encryption";
  }

}
