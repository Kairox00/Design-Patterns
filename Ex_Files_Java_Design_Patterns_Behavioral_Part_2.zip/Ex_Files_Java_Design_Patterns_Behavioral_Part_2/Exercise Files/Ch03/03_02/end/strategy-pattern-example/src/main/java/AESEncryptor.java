public class AESEncryptor implements Encryptor{

  public String encryptFile() {
    return "Applying AES encryption";
  }

}
