public interface Encryptor {

  String encryptFile();

}
