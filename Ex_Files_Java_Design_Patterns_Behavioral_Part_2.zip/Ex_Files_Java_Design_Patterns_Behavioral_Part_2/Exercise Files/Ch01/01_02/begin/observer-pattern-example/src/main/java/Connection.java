public class Connection {

  private String status = "";

  public void setStatus(String status) {
    this.status = status;
  }

}
