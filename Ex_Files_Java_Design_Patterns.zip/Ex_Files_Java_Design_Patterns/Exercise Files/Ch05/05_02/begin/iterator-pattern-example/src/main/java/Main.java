public class Main {

  public static void main(String[] args) {

    Item pens = new Item("pens", 175);
    Item pencils = new Item("pencils", 0);
    Item paper = new Item("paper", 500);


  }

}
