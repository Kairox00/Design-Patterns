public class Main {

  public static void main(String[] args) {
    Plane plane = new Plane(123);
    plane.takeOff();

  }

}
