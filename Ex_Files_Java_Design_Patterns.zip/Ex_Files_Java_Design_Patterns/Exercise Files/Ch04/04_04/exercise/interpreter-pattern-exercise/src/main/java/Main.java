public class Main {

  public static void main(String[] args) {

    String context = "this is a a sentence";

    // Interpret the sentence here

    System.out.println(context);

  }

}
