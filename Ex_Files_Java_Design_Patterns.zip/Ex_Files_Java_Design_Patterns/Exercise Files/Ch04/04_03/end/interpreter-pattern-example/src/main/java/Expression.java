public interface Expression {

  String interpret(String context);

}
