public class PrintCommand implements Command {


  public void execute() {
  }

}
