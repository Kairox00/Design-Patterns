public class SaveCommand implements Command {

  public void execute() {
  }

}
