public class DigestAuthenticationHandler extends AuthenticationHandler {

  public void handleRequest(String requestType) {
  }

}
