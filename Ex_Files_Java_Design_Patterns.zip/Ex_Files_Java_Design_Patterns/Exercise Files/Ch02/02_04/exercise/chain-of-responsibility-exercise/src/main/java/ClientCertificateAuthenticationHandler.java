public class ClientCertificateAuthenticationHandler extends AuthenticationHandler {

  public void handleRequest(String requestType) {
  }

}
