public class BasicAuthenticationHandler extends AuthenticationHandler {

  public void handleRequest(String requestType) {
  }

}
