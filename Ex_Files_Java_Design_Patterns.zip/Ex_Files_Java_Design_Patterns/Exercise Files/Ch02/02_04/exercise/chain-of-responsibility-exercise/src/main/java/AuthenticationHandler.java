public abstract class AuthenticationHandler {

  public void handleRequest(String requestType) {
  }

}
